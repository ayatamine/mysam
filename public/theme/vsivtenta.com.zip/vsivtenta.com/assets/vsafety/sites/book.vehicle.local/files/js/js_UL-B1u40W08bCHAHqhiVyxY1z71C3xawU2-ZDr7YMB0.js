/**
 * @file
 * Attaches behaviors for the Clientside Validation jQuery module.
 */
(function($, Drupal, drupalSettings) {
    'use strict';

    if (typeof drupalSettings.cvJqueryValidateOptions === 'undefined') {
        drupalSettings.cvJqueryValidateOptions = {};
    }

    if (drupalSettings.clientside_validation_jquery.force_validate_on_blur) {
        drupalSettings.cvJqueryValidateOptions.onfocusout = function(element) {
            // "eager" validation
            this.element(element);
        };
    }

    // Add messages with translations from backend.
    $.extend($.validator.messages, drupalSettings.clientside_validation_jquery.messages);

    /**
     * Attaches jQuery validate behavior to forms.
     *
     * @type {Drupal~behavior}
     *
     * @prop {Drupal~behaviorAttach} attach
     *  Attaches the outline behavior to the right context.
     */
    Drupal.behaviors.cvJqueryValidate = {
        attach: function(context) {
            if (typeof Drupal.Ajax !== 'undefined') {
                // Update Drupal.Ajax.prototype.beforeSend only once.
                if (typeof Drupal.Ajax.prototype.beforeSubmitCVOriginal === 'undefined') {
                    var validateAll = 2;
                    try {
                        validateAll = drupalSettings.clientside_validation_jquery.validate_all_ajax_forms;
                    } catch (e) {
                        // Do nothing if we do not have settings or value in settings.
                    }

                    Drupal.Ajax.prototype.beforeSubmitCVOriginal = Drupal.Ajax.prototype.beforeSubmit;
                    Drupal.Ajax.prototype.beforeSubmit = function(form_values, element_settings, options) {
                        if (typeof this.$form !== 'undefined' && (validateAll === 1 || $(this.element).hasClass('cv-validate-before-ajax')) && $(this.element).attr("formnovalidate") == undefined) {
                            $(this.$form).removeClass('ajax-submit-prevented');

                            $(this.$form).validate();
                            if (!($(this.$form).valid())) {
                                this.ajaxing = false;
                                $(this.$form).addClass('ajax-submit-prevented');
                                return false;
                            }
                        }

                        return this.beforeSubmitCVOriginal.apply(this, arguments);
                    };
                }
            }

            // Allow all modules to update the validate options.
            // Example of how to do this is shown below.
            $(document).trigger('cv-jquery-validate-options-update', drupalSettings.cvJqueryValidateOptions);

            // Process for all the forms on the page everytime,
            // we already use once so we should be good.
            $('body').find('form').once('cvJqueryValidate').each(function() {
                $(this).validate(drupalSettings.cvJqueryValidateOptions);
            });
        }
    };
})(jQuery, Drupal, drupalSettings);;
/**
 * @file
 * Attaches behaviors for the Clientside Validation jQuery module.
 */
(function($, Drupal, debounce, CKEDITOR) {
    /**
     * Attaches jQuery validate behavoir to forms.
     *
     * @type {Drupal~behavior}
     *
     * @prop {Drupal~behaviorAttach} attach
     *  Attaches the outline behavior to the right context.
     */
    Drupal.behaviors.cvJqueryValidateCKEditor = {
        attach: function(context) {
            if (typeof CKEDITOR === 'undefined') {
                return;
            }
            var ignore = ':hidden';
            var not = [];
            for (var instance in CKEDITOR.instances) {
                if (CKEDITOR.instances.hasOwnProperty(instance)) {
                    not.push('#' + instance);
                }
            }
            ignore += not.length ? ':not(' + not.join(', ') + ')' : '';
            $('form').each(function() {
                var validator = $(this).data('validator');
                if (!validator) {
                    return;
                }
                validator.settings.ignore = ignore;
                validator.settings.errorPlacement = function(place, $element) {
                    var id = $element.attr('id');
                    var afterElement = $element[0];
                    if (CKEDITOR.instances.hasOwnProperty(id)) {
                        afterElement = CKEDITOR.instances[id].container.$;
                    }
                    place.insertAfter(afterElement);
                };
            });
            var updateText = function(instance) {
                return debounce(function(e) {
                    instance.updateElement();
                    var event = $.extend(true, {}, e.data.$);
                    delete event.target;
                    delete event.explicitOriginalTarget;
                    delete event.originalTarget;
                    delete event.currentTarget;
                    $(instance.element.$).trigger(new $.Event(e.name, event));
                }, 250);
            };
            CKEDITOR.on('instanceReady', function() {
                for (var instance in CKEDITOR.instances) {
                    if (CKEDITOR.instances.hasOwnProperty(instance)) {
                        CKEDITOR.instances[instance].document.on("keyup", updateText(CKEDITOR.instances[instance]));
                        CKEDITOR.instances[instance].document.on("paste", updateText(CKEDITOR.instances[instance]));
                        CKEDITOR.instances[instance].document.on("keypress", updateText(CKEDITOR.instances[instance]));
                        CKEDITOR.instances[instance].document.on("blur", updateText(CKEDITOR.instances[instance]));
                        CKEDITOR.instances[instance].document.on("change", updateText(CKEDITOR.instances[instance]));
                    }
                }
            });
        }
    };
})(jQuery, Drupal, Drupal.debounce, (typeof CKEDITOR === 'undefined') ? undefined : CKEDITOR);;